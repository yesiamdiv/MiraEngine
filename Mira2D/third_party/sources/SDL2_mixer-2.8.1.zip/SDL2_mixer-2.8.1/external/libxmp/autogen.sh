#!/bin/sh

"${AUTOCONF:-autoconf}"
